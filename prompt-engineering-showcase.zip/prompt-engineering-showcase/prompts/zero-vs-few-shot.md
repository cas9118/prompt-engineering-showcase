# Zero-Shot vs Few-Shot Prompts

## Zero-Shot Prompt
```
Summarize the following article in one sentence.
[Insert article here]
```

## Few-Shot Prompt
```
Example 1:
Input: I feel sad and unmotivated.
Output: It sounds like you're feeling down. Want to talk about it?

Example 2:
Input: I’m feeling stressed about exams.
Output: It’s natural to feel stressed. Want a few tips to manage it?

Now, respond to the input:
Input: I can’t sleep properly lately.
Output:
```