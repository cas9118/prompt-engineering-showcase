# Tools Used in This Project

- ChatGPT (OpenAI)
- Claude (Anthropic)
- LM Studio / PromptLayer (for prompt testing)
- Excel / Google Sheets (for manual scoring)
- TruLens / Ragas (for automated prompt evaluation)
- VS Code (for editing)